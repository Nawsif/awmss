# Web performance overrides: static camera (no per-frame redraws)

init 999:
    transform parallax:
        xalign 0.5
        yalign 0.5
        perspective True
        subpixel True

init 999 python:
    persistent.parallax = False
    persistent.scene_parallax = False
    config.image_cache_size_mb = 200
